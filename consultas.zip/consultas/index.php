<?php require_once "connectDB.php";?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css"></link>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Usuarios</title>
</head>
<body>
    <h1>Consultar Usuarios</h1>
    <label>Consultar:</label>
    <input type="text" >
    <button>Agregar Cliente</button>
        <table>
            <caption>Clientes</caption>
            <tr>
                <th>ID Cliente</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Celular</th>
                <th>Opciones</th>
            </tr>
            
            <?php 
            
            $myquery = $conn->query("SELECT * FROM clients");
            $resultados = $myquery->fetchAll();
    
            foreach($resultados as $client): ?>
                <tr>
                    <td><?= htmlspecialchars($client["id_client"]) ?></td>
                    <td><?= htmlspecialchars($client["name"]) ?></td>
                    <td><?= htmlspecialchars($client["correo"]) ?></td>
                    <td><?= htmlspecialchars($client["celular"]) ?></td>
                    <td>
                    <button title="Editar">✏</button>
                    <button title="Ver">👁</button>
                    <button title="Eliminar">🗑</button>
                    </td>
    
                </tr>
            <?php endforeach; ?>
        </table>
    <?php
    ?>
</body>
</html>